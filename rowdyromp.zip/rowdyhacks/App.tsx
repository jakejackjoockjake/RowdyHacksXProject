import React, { useState } from 'react';
import { Text, View, StyleSheet, TouchableOpacity } from 'react-native';
import * as Location from 'expo-location';
import MapView, { Marker } from 'react-native-maps';
import MapViewDirections from 'react-native-maps-directions';

const GOOGLE_MAPS_APIKEY = 'AIzaSyCZ-nS2QA5lCJBpw5P5Tl43G1Ia_z1-MBA'; // API Key

const getRandomCoordinates = (latitude, longitude, radiusInMiles) => {
  const radiusInMeters = radiusInMiles * 1609.34;
  const angle = Math.random() * Math.PI * 2;
  const distance = Math.sqrt(Math.random()) * radiusInMeters;

  const deltaLat = distance * Math.cos(angle) / 111320;
  const deltaLon = distance * Math.sin(angle) / (111320 * Math.cos(latitude * (Math.PI / 180)));

  return {
    latitude: latitude + deltaLat,
    longitude: longitude + deltaLon,
  };
};

const RandomLocationGenerator = () => {
  const [location, setLocation] = useState(null);
  const [randomLocation, setRandomLocation] = useState(null);
  const [errorMsg, setErrorMsg] = useState(null);

  const getLocation = async () => {
    let { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== 'granted') {
      setErrorMsg('Permission to access location was denied');
      return;
    }

    let currentLocation = await Location.getCurrentPositionAsync({});
    setLocation(currentLocation);

    const randomCoords = getRandomCoordinates(
      currentLocation.coords.latitude,
      currentLocation.coords.longitude,
      1
    );
    setRandomLocation(randomCoords);
  };

  return (
    <View style={styles.container}>
    <View style={styles.titleContainer}>
        <Text style={styles.titleText}>Rowdy Romp</Text>
      </View>
      <View style={styles.titleContainer}>
        <Text style={styles.titleText}>Be adventurous if you dare...</Text>
      </View>

      <TouchableOpacity style={styles.button} onPress={getLocation}>
        <Text style={styles.buttonText}>Get Random Location & Path</Text>
      </TouchableOpacity>
      {errorMsg && <Text style={styles.errorText}>{errorMsg}</Text>}
      {location ? (
        <>
          <Text>Original Location:</Text>
          <Text>
            Latitude: {location.coords.latitude.toFixed(2)}, Longitude: {location.coords.longitude.toFixed(2)}
          </Text>
          {randomLocation && (
            <>
              <Text>Random Location within 1 mile:</Text>
              <Text>
                Latitude: {randomLocation.latitude.toFixed(2)}, Longitude: {randomLocation.longitude.toFixed(2)}
              </Text>
              <MapView
                style={styles.map}
                initialRegion={{
                  latitude: location.coords.latitude,
                  longitude: location.coords.longitude,
                  latitudeDelta: 0.04,
                  longitudeDelta: 0.04,
                }}
              >
                <Marker
                  coordinate={{
                    latitude: location.coords.latitude,
                    longitude: location.coords.longitude,
                  }}
                  title="Your Location"
                  pinColor="red"
                />
                <Marker
                  coordinate={{
                    latitude: randomLocation.latitude,
                    longitude: randomLocation.longitude,
                  }}
                  title="Random Location"
                  pinColor="green"
                />
                <MapViewDirections
                  origin={{
                    latitude: location.coords.latitude,
                    longitude: location.coords.longitude,
                  }}
                  destination={{
                    latitude: randomLocation.latitude,
                    longitude: randomLocation.longitude,
                  }}
                  apikey={'AIzaSyCZ-nS2QA5lCJBpw5P5Tl43G1Ia_z1-MBA'}
                  strokeWidth={4}
                  strokeColor="hotpink"
                  mode="WALKING"
                />
              </MapView>
            </>
          )}
        </>
      ) : (
        <Text>Location not yet retrieved.</Text>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0a81a',
    justifyContent: 'center',
    alignItems: 'center',
  },
  titleContainer: {
    alignItems: 'center',
    marginBottom: 20,
  },
  titleText: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#000000',
    textAlign: 'center',
  },
  button: {
    backgroundColor: '#f7dc11',
    padding: 10,
    borderRadius: 5,
    marginBottom: 20,
  },
  buttonText: {
    color: '#000000',
    fontSize: 20,
  },
  errorText: {
    color: 'black',
    fontWeight: 'underline',
    marginTop: 10,
  },
  map: {
    width: '100%',
    height: 300,
    marginTop: 20,
  },
});

export default RandomLocationGenerator;

